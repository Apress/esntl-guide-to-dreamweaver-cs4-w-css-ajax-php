<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connAdmin, $connAdmin);
$query_listUsers = "SELECT username, first_name, family_name, admin_priv FROM users ORDER BY family_name ASC";
$listUsers = mysql_query($query_listUsers, $connAdmin) or die(mysql_error());
$row_listUsers = mysql_fetch_assoc($listUsers);
$totalRows_listUsers = mysql_num_rows($listUsers);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registered Users</title>
</head>

<body>
<h1>Registered Users</h1>
<p><a href="register_user.php">Register new user</a></p>
<table width="500">
  <tr>
    <th scope="col">Name</th>
    <th scope="col">Username</th>
    <th scope="col">Administrator</th>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_listUsers['first_name']; ?> <?php echo $row_listUsers['family_name']; ?></td>
      <td><?php echo $row_listUsers['username']; ?></td>
      <td><?php echo $row_listUsers['admin_priv']; ?></td>
    </tr>
    <?php } while ($row_listUsers = mysql_fetch_assoc($listUsers)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($listUsers);
?>
