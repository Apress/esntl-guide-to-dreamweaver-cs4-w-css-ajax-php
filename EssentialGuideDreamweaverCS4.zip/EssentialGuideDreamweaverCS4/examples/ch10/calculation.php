<?php
$defaults = array(20, 10, 3);
list($x,$y,$z) = $defaults;
if ($_POST) {
  $expected = array('x','y','z');
  $i = 0;
  foreach ($_POST as $key => $value) {
    if (in_array($key, $expected)) {
	  if (!empty($value) && is_numeric($value)) {
	    ${$key} = $value;
		}
	  else {
	    $error[] = $key;
		}
	  }
	$i++;
	}
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Performing calculations</title>
<style type="text/css">
th {
	text-align:left;
	}
td, th.topRow {
	text-align:center;
	}
th.topRow {
	font-variant:small-caps;
	}
#error {
	font-weight:bold;
	color:#FF0000;
	}
</style>
</head>

<body>
<?php
if (isset($error)) {
  echo '<p id="error">Default values used for: '.implode(', ',$error).'</p>';
  }
?>
<table width="600" border="0">
  <tr>
    <th class="topRow" scope="col">Operation</th>
    <th class="topRow" scope="col">Operator</th>
    <th class="topRow" scope="col">Example</th>
    <th class="topRow" scope="col">Result</th>
  </tr>
  <tr>
    <th scope="row">Addition</th>
    <td>+</td>
    <td>$x + $y</td>
    <td><?php echo $x + $y; ?></td>
  </tr>
  <tr>
    <th scope="row">Subtraction</th>
    <td>-</td>
    <td>$x - $y</td>
    <td><?php echo $x - $y; ?></td>
  </tr>
  <tr>
    <th scope="row">Multiplication</th>
    <td>*</td>
    <td>$x * $y</td>
    <td><?php echo $x * $y; ?></td>
  </tr>
  <tr>
    <th scope="row">Division</th>
    <td>/</td>
    <td>$x / $y</td>
    <td><?php echo $x / $y; ?></td>
  </tr>
  <tr>
    <th scope="row">Modulo division</th>
    <td>%</td>
    <td>$x % $z</td>
    <td><?php echo $x % $z; ?></td>
  </tr>
  <tr>
    <th scope="row">Increment (add 1)</th>
    <td>++</td>
    <td>$x++</td>
    <td><?php echo $x++; ?></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>$x is now</td>
    <td><?php echo $x; ?></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>++$x</td>
    <td><?php echo ++$x; ?></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>$x is now</td>
    <td><?php echo $x; ?></td>
  </tr>
  <tr>
    <th scope="row">Decrement (subtract 1)</th>
    <td>--</td>
    <td>$y--</td>
    <td><?php echo $y--; ?></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>$y is now</td>
    <td><?php echo $y; ?></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>--$y</td>
    <td><?php echo --$y; ?></td>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <td>&nbsp;</td>
    <td>$y is now</td>
    <td><?php echo $y; ?></td>
  </tr>
</table>
<form id="form1" name="form1" method="post" action="">
  <fieldset>
  <legend>Set values</legend>
  <p>
    <label for="x">$x:</label>
    <input name="x" type="text" id="x" size="10" maxlength="10" /> 
    <label for="y">$y</label>
    <input name="y" type="text" id="y"  size="10" maxlength="10" />
    <label for="z">$z</label>
    <input name="z" type="text" id="z" size="10" maxlength="10" />
  </p>
  <p>
    <input type="submit" name="changeVals" id="changeVals" value="Change values" />
  </p>
  </fieldset>
  
</form>
</body>
</html>
