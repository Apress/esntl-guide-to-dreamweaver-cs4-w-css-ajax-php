<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>For loop</title>
<style type="text/css">
body {
	font-family:Arial, Helvetica, sans-serif;
	}
h1 {
	font-size:150%;
	}
p {
	font-size:85%;
	width:650px;
	}
</style>
</head>

<body>
<h1>For loop</h1>
<p>In a for loop, you initialize the counter, set the condition, and set the increment all in the first line. In this example, the counter ($i) is set to 1, the condition is set to run the loop while the counter is less than or equal to 100, and the counter is incremented by 1 each time the loop runs.</p>
<p>Switch to Code view in Dreamweaver to see the PHP code. Try changing the increment from $i++ to $i+=10.</p>
<?php
$i = 1; // set counter
for ($i = 1; $i <= 100; $i++) {
  echo $i.'<br />';
}
?>
</body>
</html>
