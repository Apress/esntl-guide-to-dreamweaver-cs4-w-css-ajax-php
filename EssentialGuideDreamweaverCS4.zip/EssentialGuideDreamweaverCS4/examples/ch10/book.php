<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Foreach loop - book</title>
<style type="text/css">
body {
	font-family:Arial, Helvetica, sans-serif;
	}
h1 {
	font-size:150%;
	}
p {
	font-size:85%;
	width:650px;
	}
</style>
</head>

<body>
<h1>Foreach loop</h1>
<p>The foreach loop is used exclusively with arrays. The alternative form of the foreach loop gives access to both the key and value of each array element. It's used mainly with associative arrays.</p>
<p>Switch to Code view in Dreamweaver to see the PHP code.</p>
<?php
$book = array('title'     => 'Essential Guide to Dreamweaver CS4',
              'author'    => 'David Powers',
			  'publisher' => 'friends of ED');
foreach ($book as $key => $value) {
  echo "The value of '$key' is '$value'<br />";
  }
?>
</body>
</html>
