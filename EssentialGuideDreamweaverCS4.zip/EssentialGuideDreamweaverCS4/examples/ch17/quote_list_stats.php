<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_quoteList = 15;
$pageNum_quoteList = 0;
if (isset($_GET['pageNum_quoteList'])) {
  $pageNum_quoteList = $_GET['pageNum_quoteList'];
}
$startRow_quoteList = $pageNum_quoteList * $maxRows_quoteList;

mysql_select_db($database_connAdmin, $connAdmin);
$query_quoteList = "SELECT quotations.quote_id, quotations.quotation, authors.first_name, authors.family_name FROM quotations LEFT JOIN authors USING (author_id) ORDER BY authors.family_name, authors.first_name, quotations.quotation";
$query_limit_quoteList = sprintf("%s LIMIT %d, %d", $query_quoteList, $startRow_quoteList, $maxRows_quoteList);
$quoteList = mysql_query($query_limit_quoteList, $connAdmin) or die(mysql_error());
$row_quoteList = mysql_fetch_assoc($quoteList);

if (isset($_GET['totalRows_quoteList'])) {
  $totalRows_quoteList = $_GET['totalRows_quoteList'];
} else {
  $all_quoteList = mysql_query($query_quoteList);
  $totalRows_quoteList = mysql_num_rows($all_quoteList);
}
$totalPages_quoteList = ceil($totalRows_quoteList/$maxRows_quoteList)-1;

$queryString_quoteList = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_quoteList") == false && 
        stristr($param, "totalRows_quoteList") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_quoteList = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_quoteList = sprintf("&totalRows_quoteList=%d%s", $totalRows_quoteList, $queryString_quoteList);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Quotations listed by author</title>
<style type="text/css">
<!--
#recNav {
	width: 700px;
}
.textRight {
	text-align: right;
}
td  {
	padding: 2px 6px;
	vertical-align: top;
}
a img {
	border: none;
}
-->
</style>
</head>

<body>
<h1>Quotations Listed by Author
</h1>
<p>Records <?php echo ($startRow_quoteList + 1) ?> to <?php echo min($startRow_quoteList + $maxRows_quoteList, $totalRows_quoteList) ?> of <?php echo $totalRows_quoteList ?> </p>
<table width="700">
  <tr>
    <th scope="col">Name</th>
    <th scope="col">Quotation</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_quoteList['first_name']; ?> <?php echo $row_quoteList['family_name']; ?></td>
      <td><?php echo $row_quoteList['quotation']; ?></td>
      <td><a href="quote_update.php?quote_id=<?php echo $row_quoteList['quote_id']; ?>">EDIT</a></td>
      <td><a href="quote_delete.php?quote_id=<?php echo $row_quoteList['quote_id']; ?>">DELETE</a></td>
    </tr>
    <?php } while ($row_quoteList = mysql_fetch_assoc($quoteList)); ?>
</table>
<table border="0" id="recNav">
  <tr>
    <td><?php if ($pageNum_quoteList > 0) { // Show if not first page ?>
      <a href="<?php printf("%s?pageNum_quoteList=%d%s", $currentPage, 0, $queryString_quoteList); ?>"><img src="First.gif" /></a>
      <?php } // Show if not first page ?>
      <?php if ($pageNum_quoteList > 0) { // Show if not first page ?>
      <a href="<?php printf("%s?pageNum_quoteList=%d%s", $currentPage, max(0, $pageNum_quoteList - 1), $queryString_quoteList); ?>"><img src="Previous.gif" /></a>
    <?php } // Show if not first page ?></td>
    <td class="textRight"><?php if ($pageNum_quoteList < $totalPages_quoteList) { // Show if not last page ?>
      <a href="<?php printf("%s?pageNum_quoteList=%d%s", $currentPage, min($totalPages_quoteList, $pageNum_quoteList + 1), $queryString_quoteList); ?>"><img src="Next.gif" /></a>
      <?php } // Show if not last page ?>
      <?php if ($pageNum_quoteList < $totalPages_quoteList) { // Show if not last page ?>
      <a href="<?php printf("%s?pageNum_quoteList=%d%s", $currentPage, $totalPages_quoteList, $queryString_quoteList); ?>"><img src="Last.gif" /></a>
    <?php } // Show if not last page ?></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($quoteList);
?>
