<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
// define the operator variable and give it a default value
$operator = '=';
// define an array of acceptable operators
$permittedOperators = array('=', '!=', '<', '<=', '>', '>=');
// get operator value from form, if submitted
if (isset($_GET['operator']) && in_array($_GET['operator'], $permittedOperators)) {
  $operator = $_GET['operator'];
}

$colname_getAuthors = "-1";
if (isset($_GET['author_id'])) {
  $colname_getAuthors = $_GET['author_id'];
}
mysql_select_db($database_connQuery, $connQuery);
$query_getAuthors = sprintf("SELECT first_name, family_name FROM authors WHERE author_id %s %s ORDER BY family_name ASC", $operator, GetSQLValueString($colname_getAuthors, "int"));
$getAuthors = mysql_query($query_getAuthors, $connQuery) or die(mysql_error());
$row_getAuthors = mysql_fetch_assoc($getAuthors);
$totalRows_getAuthors = mysql_num_rows($getAuthors);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Find an author by author_id</title>
</head>

<body>
<h1>Find an Author by author_id</h1>
<form id="form1" name="form1" method="get" action="">
  <p>
    <label for="author_id">Author_id:</label>
    <select name="operator" id="operator">
      <option value="=" <?php if (isset($_GET['operator']) && $_GET['operator'] == '=' || !isset($_GET['operator'])) {
		  echo 'selected="selected"';
	  } ?>>=</option>
      <option value="!=" <?php if (isset($_GET['operator']) && $_GET['operator'] == '!=') {
		  echo 'selected="selected"';
	  } ?>>!=</option>
      <option value="<">&lt;</option>
      <option value="<=">&lt;=</option>
      <option value=">">&gt;</option>
      <option value=">=">&gt;=</option>
    </select>
    <input type="text" name="author_id" id="author_id" />
  </p>
  <p>
    <input type="submit" name="search" id="search" value="Search" />
  </p>
</form>
<table width="200">
  <?php do { ?>
    <tr>
      <td><?php echo $row_getAuthors['first_name']; ?> <?php echo $row_getAuthors['family_name']; ?></td>
    </tr>
    <?php } while ($row_getAuthors = mysql_fetch_assoc($getAuthors)); ?>
</table>
<p> </p>
</body>
</html>
<?php
mysql_free_result($getAuthors);
?>
