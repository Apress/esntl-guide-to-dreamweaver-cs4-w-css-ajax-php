<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_getAuthors = "-1";
if (isset($_GET['first_name'])) {
  $colname_getAuthors = $_GET['first_name'];
}
mysql_select_db($database_connQuery, $connQuery);
$query_getAuthors = sprintf("SELECT first_name, family_name FROM authors WHERE first_name = BINARY %s ORDER BY family_name ASC", GetSQLValueString($colname_getAuthors, "text"));
$getAuthors = mysql_query($query_getAuthors, $connQuery) or die(mysql_error());
$row_getAuthors = mysql_fetch_assoc($getAuthors);
$totalRows_getAuthors = mysql_num_rows($getAuthors);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Find an author by first name</title>
</head>

<body>
<h1>Find an Author by First Name</h1>
<form id="form1" name="form1" method="get" action="">
  <p>
    <label for="first_name">First name (search is case sensitive):</label>
    <input type="text" name="first_name" id="first_name" />
  </p>
  <p>
    <input type="submit" name="search" id="search" value="Search" />
  </p>
</form>
<?php if (array_key_exists('search', $_GET) && $totalRows_getAuthors == 0) { // Show if form submitted and recordset empty ?>
  <p><strong>No results found</strong></p>
  <?php } // Show if recordset empty ?>
<table width="200">
  <?php do { ?>
    <tr>
      <td><?php echo $row_getAuthors['first_name']; ?> <?php echo $row_getAuthors['family_name']; ?></td>
    </tr>
    <?php } while ($row_getAuthors = mysql_fetch_assoc($getAuthors)); ?>
</table>
<p> </p>
</body>
</html>
<?php
mysql_free_result($getAuthors);
?>
