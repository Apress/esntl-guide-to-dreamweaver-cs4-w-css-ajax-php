<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  // convert the checkbox group subarray to a string
  if (isset($_POST['operating_system'])) {
    $_POST['operating_system'] = implode(',', $_POST['operating_system']);
  } else {
    $_POST['operating_system'] = 'none';
  }
  $insertSQL = sprintf("INSERT INTO os_poll (operating_system) VALUES (%s)",
                       GetSQLValueString($_POST['operating_system'], "text"));

  mysql_select_db($database_connAdmin, $connAdmin);
  $Result1 = mysql_query($insertSQL, $connAdmin) or die(mysql_error());
  mysql_select_db($database_connAdmin, $connAdmin);
  $query_getVote = "SELECT operating_system FROM os_poll ORDER BY vote_id DESC";
  $getVote = mysql_query($query_getVote, $connAdmin) or die(mysql_error());
  $row_getVote = mysql_fetch_assoc($getVote);
  $totalRows_getVote = mysql_num_rows($getVote);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Using SET columns</title>
</head>
<body>
<h1>Which Operating System Do You Use?</h1>
<form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
  <p>
    <label>
      <input type="checkbox" name="operating_system[]" value="Windows" id="operating_system_0" />
      Windows</label>
    <br />
    <label>
      <input type="checkbox" name="operating_system[]" value="Mac" id="operating_system_1" />
      Mac OS X</label>
    <br />
    <label>
      <input type="checkbox" name="operating_system[]" value="Linux" id="operating_system_2" />
      Linux</label>
    <br />
  </p>
  <p>
    <input type="submit" name="send" id="send" value="Submit" />
    <br />
  </p>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<?php if (isset($getVote)) { ?>
<p>You selected: <?php $selected = explode(',', $row_getVote['operating_system']); ?></p>
<ul>
<?php foreach ($selected as $item) {
	echo "<li>$item</li>";
}
?>
</ul>
<?php } ?>
</body>
</html>
<?php
if (isset($getVote)) {
  mysql_free_result($getVote);
}
?>
