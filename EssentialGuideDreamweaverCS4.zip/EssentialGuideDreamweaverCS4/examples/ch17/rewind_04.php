<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connQuery, $connQuery);
$query_getAuthors = "SELECT authors.first_name, authors.family_name FROM authors ORDER BY authors.family_name LIMIT 5";
$getAuthors = mysql_query($query_getAuthors, $connQuery) or die(mysql_error());
$row_getAuthors = mysql_fetch_assoc($getAuthors);
$totalRows_getAuthors = mysql_num_rows($getAuthors);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Reusing a recordset</title>
</head>

<body>
<h1>Rewinding a recordset for reuse</h1>
<p>The first five names in the authors table listed alphabetically by family name:</p>
<ul>
  <?php do { ?>
    <li><?php echo $row_getAuthors['first_name']; ?> <?php echo $row_getAuthors['family_name']; ?></li>
    <?php } while ($row_getAuthors = mysql_fetch_assoc($getAuthors)); ?>
</ul>
<?php mysql_data_seek($getAuthors, 0);
$row_getAuthors = mysql_fetch_assoc($getAuthors); ?>
<p>Let's see the first one again: <?php echo $row_getAuthors['first_name']; ?> <?php echo $row_getAuthors['family_name']; ?></p>
<table width="200">
  <tr>
    <th scope="col">First name</th>
    <th scope="col">Family name</th>
  </tr>
   <?php do { ?>
  <tr>
    <td><?php echo $row_getAuthors['first_name']; ?></td>
    <td><?php echo $row_getAuthors['family_name']; ?></td>
  </tr>
  <?php } while ($row_getAuthors = mysql_fetch_assoc($getAuthors)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($getAuthors);
?>
