<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO date_test (created, fixed_date, message) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['created'], "defined", 'NOW()'),
                       GetSQLValueString($_POST['fixed_date'], "defined", GetSQLValueString($_POST['fixed_date'], "date"), 'NOW()'),
                       GetSQLValueString($_POST['message'], "text"));

  mysql_select_db($database_connAdmin, $connAdmin);
  $Result1 = mysql_query($insertSQL, $connAdmin) or die(mysql_error());
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Inserting the current date in MySQL</title>
<style type="text/css">
.textInput {
	width: 300px;
}
</style>
</head>

<body>
<h1>Inserting the Current Date in MySQL</h1>
<form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
  <p>
    <label for="message">Message:</label>
    <input type="text" name="message" id="message" class="textInput" />
  </p>
  <p>
    <label for="fixed_date">Fixed date (leave blank for current date):</label>
    <input type="text" name="fixed_date" id="fixed_date" />
  </p>
  <p>
    <input type="submit" name="insert" id="insert" value="Insert" />
    <input name="created" type="hidden" id="created" value="NOW()" />
  </p>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
</body>
</html>