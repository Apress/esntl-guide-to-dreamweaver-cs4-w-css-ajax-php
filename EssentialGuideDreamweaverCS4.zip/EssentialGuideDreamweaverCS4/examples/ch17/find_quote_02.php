<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$var1_getQuote = "-1";
if (isset($_GET['searchTerm'])) {
  $var1_getQuote = $_GET['searchTerm'];
}
mysql_select_db($database_connQuery, $connQuery);
$query_getQuote = sprintf("SELECT quotations.quotation, authors.first_name, authors.family_name FROM quotations LEFT JOIN authors USING (author_id) WHERE quotations.quotation LIKE %s ORDER BY authors.family_name", GetSQLValueString("%" . $var1_getQuote . "%", "text"));
$getQuote = mysql_query($query_getQuote, $connQuery) or die(mysql_error());
$row_getQuote = mysql_fetch_assoc($getQuote);
$totalRows_getQuote = mysql_num_rows($getQuote);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Find a quotation</title>
<style type="text/css">
<!--
td {
	vertical-align: top;
}
-->
</style>
</head>

<body>
<h1>Find that quotation</h1>
<form id="form1" name="form1" method="get" action="">
  <p>
    <label for="searchTerm">Search for:</label>
    <input type="text" name="searchTerm" id="searchTerm" />
  </p>
  <p>
    <input type="submit" name="search" id="search" value="Submit" />
  </p>
</form>
<?php if ($totalRows_getQuote == 0) { // Show if recordset empty ?>
  <p><strong>No results found</strong></p>
  <?php } // Show if recordset empty ?>
<table width="650">
  <?php do { ?>
    <tr>
      <td><?php echo $row_getQuote['first_name']; ?> <?php echo $row_getQuote['family_name']; ?></td>
<td><?php echo nl2br($row_getQuote['quotation']); ?></td>
    </tr>
    <?php } while ($row_getQuote = mysql_fetch_assoc($getQuote)); ?>
</table>
<strong></strong>
</body>
</html>
<?php
mysql_free_result($getQuote);
?>
