<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
// initialize string for error message
$error = '';
if (array_key_exists('insert', $_POST)) {
  // formatMySQLDate definition goes here
  function formatMySQLDate($month, $date, $year, &$error) {
	$mysqlFormat = null;
	$m = $month;
	$d = trim($date);
	$y = trim($year);
	if (empty($d) || empty($y)) {
	  $error = 'Please fill in all fields';
	} elseif (!is_numeric($d) || !is_numeric($y)) {
	  $error = 'Please use numbers only';
	} elseif (($d <1 || $d > 31) || ($y < 1000 || $y > 9999)) {
	  $error = 'Please use numbers within the correct range';
	} elseif (!checkdate($m,$d,$y)) {
	  $error = 'You have used an invalid date';
	} else {
	  $d = $d < 10 ? '0'.$d : $d;
	  $mysqlFormat = "'$y-$m-$d'";
	}
	return $mysqlFormat;
  }
  // format the date parts
  $mysqlDate = formatMySQLDate($_POST['month'], $_POST['date'], $_POST['year'], $error);
}
if (!$error) {
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO date_test (created, fixed_date, message) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['created'], "defined", 'NOW()'),
                       GetSQLValueString($_POST['month'], "defined", $mysqlDate),
                       GetSQLValueString($_POST['message'], "text"));

  mysql_select_db($database_connAdmin, $connAdmin);
  $Result1 = mysql_query($insertSQL, $connAdmin) or die(mysql_error());
}
}
$months = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
$now = getdate();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Inserting a user-defined date in MySQL</title>
<style type="text/css">
.textInput {
	width: 300px;
}
</style>
</head>

<body>
<h1>Inserting a User-Defined Date in MySQL</h1>
<?php
if (isset($error)) {
  echo "<p>$error</p>";
}
?>
<form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
  <p>
    <label for="message">Message:</label>
    <input type="text" name="message" id="message" class="textInput" />
  </p>
  <p>
    <label for="month">Month:</label>
    <select name="month" id="month">
    <?php for ($i=1;$i<=12;$i++) { ?>
      <option value="<?php echo $i < 10 ? '0'.$i : $i; ?>"
      <?php if ($i == $now['mon']) {
        echo ' selected="selected"'; } ?>><?php echo $months[$i-1]; ?>
      </option>
      <?php } ?>
    </select>
    <label for="date">Date:</label>
    <input name="date" type="text" id="date" size="2" maxlength="2" />
    <label for="year">Year:</label>
    <input name="year" type="text" id="year" size="4" maxlength="4" />
  </p>
  <p>
    <input type="submit" name="insert" id="insert" value="Insert" />
    <input name="created" type="hidden" id="created" value="NOW()" />
  </p>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
</body>
</html>