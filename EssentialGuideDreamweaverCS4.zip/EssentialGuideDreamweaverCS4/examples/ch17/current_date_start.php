<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Inserting the current date in MySQL</title>
<style type="text/css">
.textInput {
	width: 300px;
}
</style>
</head>

<body>
<h1>Inserting the Current Date in MySQL</h1>
<form id="form1" name="form1" method="POST">
  <p>
    <label for="message">Message:</label>
    <input type="text" name="message" id="message" class="textInput" />
  </p>
  <p>
    <label for="fixed_date">Fixed date (leave blank for current date):</label>
    <input type="text" name="fixed_date" id="fixed_date" />
  </p>
  <p>
    <input type="submit" name="insert" id="insert" value="Insert" />
  </p>
</form>
</body>
</html>