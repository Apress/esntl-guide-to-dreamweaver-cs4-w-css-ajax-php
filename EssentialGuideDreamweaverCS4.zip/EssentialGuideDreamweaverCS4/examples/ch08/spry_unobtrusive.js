
function init()
{
	Spry.$$('li:nth-child(odd)').addClassName('odd');
	Spry.$$('li:nth-child(even)').addClassName('even');
	Spry.$$('p.hideMe').removeClassName('hideMe');
}
function showCoauthored()
{
	Spry.$$('li.coauthored').toggleClassName('hideMe');
}



Spry.Utils.addLoadListener(function() {
	var onloadCallback = function(e){ init() }; // body
	Spry.$$("body").addEventListener('load', onloadCallback, false).forEach(function(n){ onloadCallback.call(n); });
	Spry.$$("#a1").addEventListener('click', function(e){ showCoauthored() }, false);
});
