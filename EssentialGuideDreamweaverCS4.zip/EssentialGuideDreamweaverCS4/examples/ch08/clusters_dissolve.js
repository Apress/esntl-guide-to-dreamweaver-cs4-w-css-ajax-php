// JavaScript Document

Dissolve = function(elem1, elem2, duration)
{
  var dur = 2000;
  if (duration != null) dur = duration;
  Spry.Effect.Cluster.call(this, {duration: dur});
  var fadeOut = new Spry.Effect.Opacity(elem1, 1, 0, {duration: dur, toggle: true});
  var fadeIn = new Spry.Effect.Opacity(elem2, 0, 1, {duration: dur, toggle: true});
  this.addParallelEffect(fadeOut);
  this.addParallelEffect(fadeIn);
};
Dissolve.prototype = new Spry.Effect.Cluster();
Dissolve.prototype.constructor = Dissolve;