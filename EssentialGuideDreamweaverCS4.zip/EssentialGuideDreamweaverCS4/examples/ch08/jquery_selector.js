
$(function()
		   {
			   $('li:even').addClass('even');
			   $('li:odd').addClass('odd');
			   $('<p class="clickable">Show/hide co-authored books</p>').click(function()
																						{
																							$('li.coauthored').toggleClass('hideMe');
																						}).insertAfter('#heading');
		   });


