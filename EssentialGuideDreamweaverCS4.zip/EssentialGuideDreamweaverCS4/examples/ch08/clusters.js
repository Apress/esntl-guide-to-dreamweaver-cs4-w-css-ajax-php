// JavaScript Document

Dissolve = function(elem1, elem2, duration)
{
  var dur = 2000;
  if (duration != null) dur = duration;
  Spry.Effect.Cluster.call(this, {duration: dur});
  var fadeOut = new Spry.Effect.Opacity(elem1, 1, 0, {duration: dur, toggle: true});
  var fadeIn = new Spry.Effect.Opacity(elem2, 0, 1, {duration: dur, toggle: true});
  this.addParallelEffect(fadeOut);
  this.addParallelEffect(fadeIn);
};
Dissolve.prototype = new Spry.Effect.Cluster();
Dissolve.prototype.constructor = Dissolve;

HighlightTransition = function(element, options)
{
	Spry.Effect.Cluster.call(this, options);
	var col1 = '#FFFFFF';
	var col2 = '#DCBD7D';
	var col3 = '#FFFFFF';
	var dur1 = 2000;
	var dur2 = 2000;
	if (options.col1 != null) col1 = options.col1;
	if (options.col2 != null) col2 = options.col2;
	if (options.col3 != null) col3 = options.col3;
	if (options.dur1 != null) dur1 = options.dur1;
	if (options.dur2 != null) dur2 = options.dur2;
	var transition1 = new Spry.Effect.Color(element, col1, col2, {duration: dur1, transition: Spry.sinusoidalTransition});
	var transition2 = new Spry.Effect.Color(element, col2, col3, {duration: dur2, transition: Spry.sinusoidalTransition});
	this.addNextEffect(transition1);
	this.addNextEffect(transition2);
};
HighlightTransition.prototype = new Spry.Effect.Cluster();
HighlightTransition.prototype.constructor = HighlightTransition;