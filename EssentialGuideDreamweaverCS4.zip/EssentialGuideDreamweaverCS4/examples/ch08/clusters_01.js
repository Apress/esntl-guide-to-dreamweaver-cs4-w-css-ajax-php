// JavaScript Document

Dissolve = function(elem1, elem2, duration)
{
  Spry.Effect.Cluster.call(this, {duration: duration});
  var fadeOut = new Spry.Effect.Opacity(elem1, 1, 0, {duration: duration, toggle: true});
  var fadeIn = new Spry.Effect.Opacity(elem2, 0, 1, {duration: duration, toggle: true});
  this.addParallelEffect(fadeOut);
  this.addParallelEffect(fadeIn);
};
Dissolve.prototype = new Spry.Effect.Cluster();
Dissolve.prototype.constructor = Dissolve;