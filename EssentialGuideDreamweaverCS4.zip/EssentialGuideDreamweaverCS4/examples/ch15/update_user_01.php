<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

$colname_getUser = "-1";
if (isset($_GET['user_id'])) {
  $colname_getUser = $_GET['user_id'];
}
mysql_select_db($database_connAdmin, $connAdmin);
$query_getUser = sprintf("SELECT user_id, username, pwd, first_name, family_name, admin_priv FROM users WHERE user_id = %s", GetSQLValueString($colname_getUser, "int"));
$getUser = mysql_query($query_getUser, $connAdmin) or die(mysql_error());
$row_getUser = mysql_fetch_assoc($getUser);
$totalRows_getUser = mysql_num_rows($getUser);

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  // Initialize array for error messages
  $error = array();
  // Remove whitespace and check first and family names
  $_POST['first_name'] = trim($_POST['first_name']);
  $_POST['family_name'] = trim($_POST['family_name']); 
  if (empty($_POST['first_name']) || empty($_POST['family_name'])) {
    $error['name'] = 'Please enter both first name and family name';
  }
  // Check the username for length
  $_POST['username'] = trim($_POST['username']);
  if (strlen($_POST['username']) < 6) {
    $error['length'] = 'Please select a username that contains at least 6 characters';
  }
  // set a flag that assumes the password is OK
  $pwdOK = true;
  // trim leading and trailing white space
  $_POST['pwd'] = trim($_POST['pwd']);
  // if password field is empty, use existing password
  if (empty($_POST['pwd'])) {
    $_POST['pwd'] = $row_getUser['pwd'];
  } else {
    // otherwise, conduct normal checks
    // if less than 6 characters, create alert and set flag to false
    if (strlen($_POST['pwd']) < 6) {
      $error['pwd_length'] = 'Your password must be at least 6 characters';
      $pwdOK = false;
    }
    // if no match, create alert and set flag to false
    if ($_POST['pwd'] != trim($_POST['conf_pwd'])) {
	  $error['pwd'] = "Your passwords don't match";
	  $pwdOK = false;
    }
    // if password OK, encrypt it
    if ($pwdOK) {
	  $_POST['pwd'] = sha1($_POST['pwd']);
	}
  }

  // update the record if there are no errors
  if (!$error) {
    $updateSQL = sprintf("UPDATE users SET first_name=%s, family_name=%s, username=%s, pwd=%s, admin_priv=%s WHERE user_id=%s",
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['family_name'], "text"),
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['pwd'], "text"),
                       GetSQLValueString($_POST['admin_priv'], "text"),
                       GetSQLValueString($_POST['user_id'], "int"));

    mysql_select_db($database_connAdmin, $connAdmin);
    $Result1 = mysql_query($updateSQL, $connAdmin);
	if (!$Result1 && mysql_errno() == 1062) {
      $error['username'] = $_POST['username'] . ' is already in use. Please choose a different username.';
    } elseif (mysql_error()) {
	  $error['dbError'] = 'Sorry, there was a problem with the database. Please try later.';
    } else {
      $updateGoTo = "list_users.php";
      if (isset($_SERVER['QUERY_STRING'])) {
        $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
        $updateGoTo .= $_SERVER['QUERY_STRING'];
      }
      header(sprintf("Location: %s", $updateGoTo));
	}
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Update User Record</title>
</head>

<body>
<h1>Update User Record</h1>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">First name:</td>
      <td><input type="text" name="first_name" value="<?php echo htmlentities($row_getUser['first_name'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Family name:</td>
      <td><input type="text" name="family_name" value="<?php echo htmlentities($row_getUser['family_name'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Username:</td>
      <td><input type="text" name="username" value="<?php echo htmlentities($row_getUser['username'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Password:<br />
        (leave blank if unchanged)</td>
      <td><input type="password" name="pwd" value="<?php echo htmlentities($row_getUser['pwd'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Confirm password: </td>
      <td valign="baseline"><input type="password" name="conf_pwd" id="conf_pwd" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Administrator:</td>
      <td valign="baseline"><table>
        <tr>
          <td><input type="radio" name="admin_priv" value="y" <?php if (!(strcmp(htmlentities($row_getUser['admin_priv'], ENT_COMPAT, 'utf-8'),"y"))) {echo "checked=\"checked\"";} ?> />
            Yes</td>
        </tr>
        <tr>
          <td><input type="radio" name="admin_priv" value="n" <?php if (!(strcmp(htmlentities($row_getUser['admin_priv'], ENT_COMPAT, 'utf-8'),"n"))) {echo "checked=\"checked\"";} ?> />
            No</td>
        </tr>
      </table></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Update record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="user_id" value="<?php echo $row_getUser['user_id']; ?>" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($getUser);
?>
