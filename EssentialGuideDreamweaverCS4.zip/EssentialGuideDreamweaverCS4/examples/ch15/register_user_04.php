<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  // Initialize array for error messages
  $error = array();
  // Remove whitespace and check first and family names
  $_POST['first_name'] = trim($_POST['first_name']);
  $_POST['family_name'] = trim($_POST['family_name']); 
  if (empty($_POST['first_name']) || empty($_POST['family_name'])) {
    $error['name'] = 'Please enter both first name and family name';
  }
  // Check the username for length
  $_POST['username'] = trim($_POST['username']);
  if (strlen($_POST['username']) < 6) {
    $error['length'] = 'Please select a username that contains at least 6 characters';
  }
  // set a flag that assumes the password is OK
  $pwdOK = true;
  // trim leading and trailing white space
  $_POST['pwd'] = trim($_POST['pwd']);
  // if less than 6 characters, create alert and set flag to false
  if (strlen($_POST['pwd']) < 6) {
    $error['pwd_length'] = 'Your password must be at least 6 characters';
    $pwdOK = false;
  }
  // if no match, create alert and set flag to false
  if ($_POST['pwd'] != trim($_POST['conf_pwd'])) {
	$error['pwd'] = "Your passwords don't match";
	$pwdOK = false;
  }
  // if password OK, encrypt it
  if ($pwdOK) {
	$_POST['pwd'] = sha1($_POST['pwd']);
  }
  
  // if no errors, insert the details into the database 
  if (!$error) {
    $insertSQL = sprintf("INSERT INTO users (first_name, family_name, username, pwd, admin_priv) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['family_name'], "text"),
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['pwd'], "text"),
                       GetSQLValueString($_POST['admin_priv'], "text"));

    mysql_select_db($database_connAdmin, $connAdmin);
    $Result1 = mysql_query($insertSQL, $connAdmin);
    if (!$Result1 && mysql_errno() == 1062) {
      $error['username'] = $_POST['username'] . ' is already in use. Please choose a different username.';
    } elseif (mysql_error()) {
	  $error['dbError'] = 'Sorry, there was a problem with the database. Please try later.';
    } else {
      $insertGoTo = "list_users.php";
      if (isset($_SERVER['QUERY_STRING'])) {
       $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
        $insertGoTo .= $_SERVER['QUERY_STRING'];
      }
      header(sprintf("Location: %s", $insertGoTo));
	}
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Register User</title>
</head>

<body>
<h1>Register User</h1>
<?php
if (isset($error)) {
  echo '<ul>';
  foreach ($error as $alert) {
    echo "<li class='warning'>$alert</li>\n";
  }
  echo '</ul>';
}
?>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">First name:</td>
      <td><input type="text" name="first_name" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Family name:</td>
      <td><input type="text" name="family_name" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Username:</td>
      <td><input type="text" name="username" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Password:</td>
      <td><input type="password" name="pwd" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Confirm password: </td>
      <td valign="baseline"><input type="password" name="conf_pwd" id="conf_pwd" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Administrator:</td>
      <td valign="baseline"><table>
        <tr>
          <td><input type="radio" name="admin_priv" value="y" <?php if (!(strcmp("n","y"))) {echo "checked=\"checked\"";} ?> />
            Yes</td>
        </tr>
        <tr>
          <td><input type="radio" name="admin_priv" value="n" <?php if (!(strcmp("n","n"))) {echo "checked=\"checked\"";} ?> />
            No</td>
        </tr>
      </table></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Insert record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1" />
</form>
<p>&nbsp;</p>
</body>
</html>