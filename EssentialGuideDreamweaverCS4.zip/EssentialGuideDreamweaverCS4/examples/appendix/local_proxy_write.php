<?php
$url = 'http://dwcs4/workfiles/appendix/japan_xml.php';
// Get remote headers
$headers = get_headers($url);
// Make sure the first header includes 'OK'
if (stripos($headers[0] , 'OK')) {
  $xml = file_get_contents($url);
  // Set the name of the file to write the XML to
  $xmlfile = 'japan_proxy.xml';
  // function to overwrite content in a file
  function writeToFile($content, $targetFile) {
	// open the file ready for writing
	if (!$file = fopen($targetFile, 'w')) {
	  echo "Cannot create $targetFile";
	  exit;
	}
	// write the content to the file
	if (fwrite($file,$content) === false) {
	  echo "Cannot write to $targetFile";
	  exit;
	}
	echo "Success: content updated in $targetFile";
	// close the file
	fclose($file);
  }
  // Write to the file
  writeToFile($xml, $xmlfile);
} else {
  echo "Cannot open file at $url";
}
?>
