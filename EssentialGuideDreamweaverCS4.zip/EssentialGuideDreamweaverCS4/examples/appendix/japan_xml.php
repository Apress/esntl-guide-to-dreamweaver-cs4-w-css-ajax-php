<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connQuery, $connQuery);
$query_getPhotos = "SELECT filename, width, height, caption, `description` FROM ch19_gallery WHERE category = 'JPN'";
$getPhotos = mysql_query($query_getPhotos, $connQuery) or die(mysql_error());
$row_getPhotos = mysql_fetch_assoc($getPhotos);
$totalRows_getPhotos = mysql_num_rows($getPhotos);
// Send the headers
header('Content-type: text/xml');
header('Pragma: public');
header('Cache-control: private');
header('Expires: -1');
// Add the XML declaration
echo '<?xml version="1.0" encoding="utf-8"?>';
?>
<gallery>
<?php do { ?>
  <photo>
    <filename><?php echo $row_getPhotos['filename']; ?></filename>
    <width><?php echo $row_getPhotos['width']; ?></width>
    <height><?php echo $row_getPhotos['height']; ?></height>
    <caption>
    <?php echo $row_getPhotos['caption']; ?>
    </caption>
    <description><?php echo $row_getPhotos['description']; ?></description>
  </photo>
  <?php } while ($row_getPhotos = mysql_fetch_assoc($getPhotos)); ?>
</gallery>
<?php
mysql_free_result($getPhotos);
?>
