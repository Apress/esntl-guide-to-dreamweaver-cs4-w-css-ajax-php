<?php
$url = 'http://friendsofed.com/news.php';
// Open the cURL session
if ($session = curl_init($url)) {
  // Block HTTP headers, and get XML only
  curl_setopt($session, CURLOPT_HEADER, false);
  curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
  // Get the remote feed
  $remote = curl_exec($session);
  // Close the cURL session
  curl_close($session);
  // Check that the feed was retrieved successfully
  if ($remote) {
    // Send an XML header and display the feed
    header('Content-Type: text/xml');
    echo $remote;
  } else {
    echo "No content found at $url";
  }
} else {
  echo "Cannot initialize remote session";
}
?>
