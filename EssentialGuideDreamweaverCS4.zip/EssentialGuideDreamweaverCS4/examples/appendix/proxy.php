<?php
$url = 'http://friendsofed.com/news.php';
// Get remote headers
$headers = get_headers($url);
// Make sure the first header includes 'OK'
if (stripos($headers[0] , 'OK')) {
  $remote = file_get_contents($url);
  // Send an XML header and display the feed
  header('Content-Type: text/xml');
  echo $remote;
} else {
  echo "Cannot open remote file at $url";
}
?>
