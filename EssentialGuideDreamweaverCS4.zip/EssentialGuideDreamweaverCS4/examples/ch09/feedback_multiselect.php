<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact form</title>
<link href="contact.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Contact Us</h1>
<p>We welcome feedback from visitors to our site. Please use the following form to let us know what you think about it.</p>
<form id="form1" name="form1" method="post" action="">
  <p>
    <label for="name">Name:</label>
    <input name="name" type="text" class="textInput" id="name" />
  </p>
  <p>
    <label for="email">Email:</label>
    <input name="email" type="text" class="textInput" id="email" />
  </p>
  <p>
    <label for="comments">Comments:</label>
    <textarea name="comments" id="comments" cols="45" rows="5"></textarea>
  </p>
  <p><strong>What aspects of London most interest you?</strong></p>
  <p class="chkRad">
    <label>
      <input type="checkbox" name="interests[]" value="Classical concerts" id="interests_0" />
      Classical concerts</label>
    <br />
    <label>
      <input type="checkbox" name="interests[]" value="Rock/pop" id="interests_1" />
      Rock & pop events</label>
    <br />
    <label>
      <input type="checkbox" name="interests[]" value="Drama" id="interests_2" />
      Drama</label>
    </p>
    <p class="chkRad">
    <label>
      <input type="checkbox" name="interests[]" value="Walks" id="interests_3" />
      Guided walks</label>
    <br />
    <label>
      <input type="checkbox" name="interests[]" value="Art" id="interests_4" />
      Art</label>
  </p>
    <p class="clearIt"><strong>Would you like to receive regular details of events in London?</strong></p>
    <p class="chkRad">
      <label>
        <input type="radio" name="subscribe" id="subscribeYes" value="y" />
        Yes</label>
    </p>
    <p class="chkRad">
      <label>
<input name="subscribe" type="radio" id="subscribeNo" value="n" checked="checked" />
No</label>
    </p>
    <p class="clearIt">
      <label for="visited">How often have you been to London?</label>
      <select name="visited" id="visited">
        <option value="0" selected="selected"> -- Select one --</option>
        <option value="Never">Never been</option>
        <option value="1-2 times">Once or twice</option>
        <option value="Not yearly">Less than once a year</option>
        <option value="Yearly">I go most years</option>
        <option value="Resident">I live there</option>
      </select>
    </p>
    <p>
      <label for="views">What image do you have of London?</label>
      <select name="views[]" size="6" multiple="multiple" id="views">
        <option value="Vibrant/exciting">A vibrant, exciting city</option>
        <option value="Good food">A great place to eat</option>
        <option value="Good transport">Convenient transport</option>
        <option value="Dull">Dull, dull, dull</option>
        <option value="Bad food">The food's rotten</option>
        <option value="Transport nightmare">A transport nightmare</option>
      </select>
    </p>
  <p class="clearIt">
    <input name="send" type="submit" id="send" value="Send comments" />
  </p>
</form>
<pre>
<?php if ($_POST) {print_r($_POST);} ?>
</pre>
</body>
</html>