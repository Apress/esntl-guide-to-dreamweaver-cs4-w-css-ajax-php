<?php
//XMLXSL Transformation class
require_once('../../includes/MM_XSLTransform/MM_XSLTransform.class.php'); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Good books</title>
</head>

<body>
<h1>Good books</h1>
<?php
$mm_xsl = new MM_XSLTransform();
$mm_xsl->setXML("../../examples/ch18/booklist.xml");
$mm_xsl->setXSL("books6.xsl");
echo $mm_xsl->Transform();
?>
</body>
</html>