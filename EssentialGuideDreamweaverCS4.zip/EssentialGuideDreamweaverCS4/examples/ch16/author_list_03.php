<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_listAuthors = 15;
$pageNum_listAuthors = 0;
if (isset($_GET['pageNum_listAuthors'])) {
  $pageNum_listAuthors = $_GET['pageNum_listAuthors'];
}
$startRow_listAuthors = $pageNum_listAuthors * $maxRows_listAuthors;

mysql_select_db($database_connAdmin, $connAdmin);
$query_listAuthors = "SELECT author_id, first_name, family_name FROM authors ORDER BY family_name, authors.first_name";
$query_limit_listAuthors = sprintf("%s LIMIT %d, %d", $query_listAuthors, $startRow_listAuthors, $maxRows_listAuthors);
$listAuthors = mysql_query($query_limit_listAuthors, $connAdmin) or die(mysql_error());
$row_listAuthors = mysql_fetch_assoc($listAuthors);

if (isset($_GET['totalRows_listAuthors'])) {
  $totalRows_listAuthors = $_GET['totalRows_listAuthors'];
} else {
  $all_listAuthors = mysql_query($query_listAuthors);
  $totalRows_listAuthors = mysql_num_rows($all_listAuthors);
}
$totalPages_listAuthors = ceil($totalRows_listAuthors/$maxRows_listAuthors)-1;

$queryString_listAuthors = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_listAuthors") == false && 
        stristr($param, "totalRows_listAuthors") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_listAuthors = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_listAuthors = sprintf("&totalRows_listAuthors=%d%s", $totalRows_listAuthors, $queryString_listAuthors);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>List of registered authors</title>
<style type="text/css">
<!--
#recNav {
	width: 400px;
}
.textRight {
	text-align: right;
}
a img {
	border: none;
}
-->
</style>
</head>

<body>
<h1>Registered Authors</h1>
<table width="450">
  <tr>
    <th scope="col">Author</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_listAuthors['first_name']; ?> <?php echo $row_listAuthors['family_name']; ?></td>
      <td><a href="author_update.php?author_id=<?php echo $row_listAuthors['author_id'];
	  if ($pageNum_listAuthors) {
		echo '&amp;pageNum_listAuthors='.$pageNum_listAuthors;
	  }?>">EDIT</a></td>
      <td><a href="author_delete.php?author_id=<?php echo $row_listAuthors['author_id']; ?>">DELETE</a></td>
    </tr>
    <?php } while ($row_listAuthors = mysql_fetch_assoc($listAuthors)); ?>
</table>
<table border="0" id="recNav">
  <tr>
    <td><?php if ($pageNum_listAuthors > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_listAuthors=%d%s", $currentPage, 0, $queryString_listAuthors); ?>"><img src="First.gif" /></a>
        <?php } // Show if not first page ?> <?php if ($pageNum_listAuthors > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_listAuthors=%d%s", $currentPage, max(0, $pageNum_listAuthors - 1), $queryString_listAuthors); ?>"><img src="Previous.gif" /></a>
    <?php } // Show if not first page ?></td>
    <td class="textRight"><?php if ($pageNum_listAuthors < $totalPages_listAuthors) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_listAuthors=%d%s", $currentPage, min($totalPages_listAuthors, $pageNum_listAuthors + 1), $queryString_listAuthors); ?>"><img src="Next.gif" /></a>
        <?php } // Show if not last page ?> <?php if ($pageNum_listAuthors < $totalPages_listAuthors) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_listAuthors=%d%s", $currentPage, $totalPages_listAuthors, $queryString_listAuthors); ?>"><img src="Last.gif" /></a>
    <?php } // Show if not last page ?></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($listAuthors);
?>
