<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}


$var1_checkAuthor = "-1";
if (isset($_POST['first_name'])) {
  $var1_checkAuthor = $_POST['first_name'];
}
$var2_checkAuthor = "-1";
if (isset($_POST['family_name'])) {
  $var2_checkAuthor = $_POST['family_name'];
}
mysql_select_db($database_connAdmin, $connAdmin);
$query_checkAuthor = sprintf("SELECT authors.author_id, authors.first_name, authors.family_name FROM authors WHERE authors.first_name = %s AND authors.family_name = %s", GetSQLValueString($var1_checkAuthor, "text"),GetSQLValueString($var2_checkAuthor, "text"));
$checkAuthor = mysql_query($query_checkAuthor, $connAdmin) or die(mysql_error());
$row_checkAuthor = mysql_fetch_assoc($checkAuthor);
$totalRows_checkAuthor = mysql_num_rows($checkAuthor);

$colname_getAuthor = "-1";
if (isset($_GET['author_id'])) {
  $colname_getAuthor = $_GET['author_id'];
}
mysql_select_db($database_connAdmin, $connAdmin);
$query_getAuthor = sprintf("SELECT author_id, first_name, family_name FROM authors WHERE author_id = %s", GetSQLValueString($colname_getAuthor, "int"));
$getAuthor = mysql_query($query_getAuthor, $connAdmin) or die(mysql_error());
$row_getAuthor = mysql_fetch_assoc($getAuthor);
$totalRows_getAuthor = mysql_num_rows($getAuthor);
// assume that no match has been found
$alreadyRegistered = false;

// check whether recordset found any matches
if ($totalRows_checkAuthor > 0) {
  // if found, reset $alreadyRegistered
  $alreadyRegistered = true;
} else {
  // go ahead with server behavior
  if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE authors SET first_name=%s, family_name=%s WHERE author_id=%s",
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['family_name'], "text"),
                       GetSQLValueString($_POST['author_id'], "int"));

  mysql_select_db($database_connAdmin, $connAdmin);
  $Result1 = mysql_query($updateSQL, $connAdmin) or die(mysql_error());

  $updateGoTo = "author_list.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Update author</title>
<link href="form.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Update Author</h1>
<?php
if ($_POST && $alreadyRegistered) {
  echo '<p class="warning">'.$_POST['first_name'].' '.$_POST['family_name'].' is already registered</p>';
}
?>

<form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
  <p>
    <label for="first_name">First name:</label>
<input name="first_name" type="text" id="first_name" value="<?php echo $row_getAuthor['first_name']; ?>" />
  </p>
  <p>
    <label for="family_name">Family name:</label>
<input name="family_name" type="text" id="family_name" value="<?php echo $row_getAuthor['family_name']; ?>" />
  </p>
  <p>
    <input type="submit" name="update" id="update" value="Update author" />
    <input name="author_id" type="hidden" id="author_id" value="<?php echo $row_getAuthor['author_id']; ?>" />
  </p>
  <input type="hidden" name="MM_update" value="form1" />
</form>
<p><a href="author_list.php">List authors</a></p>
</body>
</html>
<?php
mysql_free_result($checkAuthor);

mysql_free_result($getAuthor);
?>
