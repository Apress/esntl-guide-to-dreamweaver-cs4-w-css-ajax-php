<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connAdmin, $connAdmin);
$query_listAuthors = "SELECT authors.author_id, authors.first_name, authors.family_name FROM authors ORDER BY authors.family_name, authors.first_name";
$listAuthors = mysql_query($query_listAuthors, $connAdmin) or die(mysql_error());
$row_listAuthors = mysql_fetch_assoc($listAuthors);
$totalRows_listAuthors = mysql_num_rows($listAuthors);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>List of registered authors</title>
</head>

<body>
<h1>Registered authors</h1>
<table width="450">
  <tr>
    <th scope="col">Author</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td><?php echo $row_listAuthors['first_name']; ?> <?php echo $row_listAuthors['family_name']; ?></td>
    <td><a href="author_update.php?author_id=<?php echo $row_listAuthors['author_id']; ?>">EDIT</a></td>
    <td><a href="author_delete.php?author_id=<?php echo $row_listAuthors['author_id']; ?>">DELETE</a></td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($listAuthors);
?>
