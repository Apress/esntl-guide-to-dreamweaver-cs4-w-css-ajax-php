<?php require_once('../../Connections/connAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connAdmin, $connAdmin);
$query_getAuthors = "SELECT authors.author_id, authors.first_name, authors.family_name FROM authors ORDER BY authors.family_name, authors.first_name";
$getAuthors = mysql_query($query_getAuthors, $connAdmin) or die(mysql_error());
$row_getAuthors = mysql_fetch_assoc($getAuthors);
$totalRows_getAuthors = mysql_num_rows($getAuthors);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insert new quotation</title>
<link href="form.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Insert New Quotation</h1>
<form id="form1" name="form1" method="post" action="">
  <p>
    <label for="quotation">Quotation:</label>
    <textarea name="quotation" id="quotation" cols="45" rows="5"></textarea>
  </p>
  <p>
    <label for="author_id">Author:</label>
    <select name="author_id" id="author_id">
      <option value="">Not registered</option>
      <?php
do {  
?>
      <option value="<?php echo $row_getAuthors['author_id']?>"><?php echo $row_getAuthors['family_name']?></option>
      <?php
} while ($row_getAuthors = mysql_fetch_assoc($getAuthors));
  $rows = mysql_num_rows($getAuthors);
  if($rows > 0) {
      mysql_data_seek($getAuthors, 0);
	  $row_getAuthors = mysql_fetch_assoc($getAuthors);
  }
?>
    </select>
  </p>
  <p>
    <input type="submit" name="insert" id="insert" value="Insert quotation" />
  </p>
</form>
<p><a href="quote_list.php">List quotations</a></p>
</body>
</html>
<?php
mysql_free_result($getAuthors);
?>
