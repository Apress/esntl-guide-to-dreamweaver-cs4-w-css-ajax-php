<?php
if (array_key_exists('send', $_POST)) {
  // mail processing script
  // remove escape characters from POST array
  if (PHP_VERSION < 6 && get_magic_quotes_gpc()) {
    function stripslashes_deep($value) {
	  $value = is_array($value) ? array_map('stripslashes_deep', $value) : stripslashes($value);
	  return $value;
	}
    $_POST = array_map('stripslashes_deep', $_POST);
  }

  $to = 'me@example.com'; // use your own email address
  $subject = 'Feedback from Essential Guide';
  
  // list expected fields
  $expected = array('name', 'email', 'comments', 'interests', 'subscribe', 'visited', 'views');
  // set required fields
  $required = array('name', 'comments', 'interests', 'visited', 'views');
  // create empty array for any missing fields
  $missing = array();
  // set default values for variables that might not exist
  if (!isset($_POST['interests'])) {
    $_POST['interests'] = array();
  }
  if (!isset($_POST['views'])) {
    $_POST['views'] = array();
  }
  // minimum number of required checkboxes
  $minCheckboxes = 2;
  // if fewer than required, add to $missing array
  if (count($_POST['interests']) < $minCheckboxes) {
	$missing[] = 'interests';
  }

  // assume that there is nothing suspect
  $suspect = false;
  // create a pattern to locate suspect phrases
  $pattern = '/Content-Type:|Bcc:|Cc:/i';
  
  // function to check for suspect phrases
  function isSuspect($val, $pattern, &$suspect) {
    // if the variable is an array, loop through each element
    // and pass it recursively back to the same function
    if (is_array($val)) {
      foreach ($val as $item) {
         isSuspect($item, $pattern, $suspect);
      }
    } else {
      // if one of the suspect phrases is found, set Boolean to true
      if (preg_match($pattern, $val)) {
        $suspect = true;
      }
    }
  }

  // check the $_POST array and any subarrays for suspect content
  isSuspect($_POST, $pattern, $suspect);

  if ($suspect) {
    $mailSent = false;
    unset($missing);
  } else {
    // process the $_POST variables
    foreach ($_POST as $key => $value) {
      // assign to temporary variable and strip whitespace if not an array
      $temp = is_array($value) ? $value : trim($value);
      // if empty and required, add to $missing array
      if (empty($temp) && in_array($key, $required)) {
        array_push($missing, $key);
      } elseif (in_array($key, $expected)) {
	    // otherwise, assign to a variable of the same name as $key
        ${$key} = $temp;
      }
    }
  }
  
  // validate the email address
  if (!empty($email)) {
    // regex to identify illegal characters in email address
    $checkEmail = '/^[^@]+@[^\s\r\n\'";,@%]+$/';
	// reject the email address if it doesn't match
    if (!preg_match($checkEmail, $email)) {
      $suspect = true;
      $mailSent = false;
      unset($missing);
    }
  }

  
  // go ahead only if not suspect and all required fields OK
  if (!$suspect && empty($missing)) {
  
    // build the message
    $message = "Name: $name\n\n";
    $message .= "Email: $email\n\n";
    $message .= "Comments: $comments\n\n";
	$message .= 'Interests: '.implode(', ', $interests)."\n\n";
	$message .= "Subscribe: $subscribe\n\n";
	$message .= "Visited: $visited\n\n";
	$message .= 'Impressions of London: '.implode(', ', $views);

    // limit line length to 70 characters
    $message = wordwrap($message, 70);

     // create additional headers
     $headers = "From: Essential Guide<feedback@example.com>\r\n";
	 $headers .= 'Content-Type: text/plain; charset=utf-8';
     if (!empty($email)) {
       $headers .= "\r\nReply-To: $email";
     }

	 
    // send it  
    $mailSent = mail($to, $subject, $message, $headers);
    if ($mailSent) {
      // $missing is no longer needed if the email is sent, so unset it
      unset($missing);
    }
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact form</title>
<link href="contact.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Contact Us</h1>
<?php
if ($_POST && isset($missing) && !empty($missing)) {
?>
  <p class="warning">Please complete the missing item(s) indicated.</p>
<?php
} elseif ($_POST && !$mailSent) {
?>
  <p class="warning">Sorry, there was a problem sending your message. Please try later.</p>
<?php
} elseif ($_POST && $mailSent) {
?>
  <p><strong>Your message has been sent. Thank you for your feedback.</strong></p>
<?php } ?>
<p>We welcome feedback from visitors to our site. Please use the following form to let us know what you think about it.</p>
<form id="form1" name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>">
  <fieldset>
    <legend>Your details</legend>
    <p>
      <label for="name">Name: <?php
      if (isset($missing) && in_array('name', $missing)) { ?>
      <span class="warning">Please enter your name</span><?php } ?>
      </label>
      <input name="name" type="text" class="textInput" id="name" 
      <?php if (isset($missing)) {
		echo 'value="' . htmlentities($_POST['name'], ENT_COMPAT, 'UTF-8') . '"';
	  } ?>
      />
    </p>
    <p>
      <label for="email">Email: </label>
      <input name="email" type="text" class="textInput" id="email" 
      <?php if (isset($missing)) {
		echo 'value="' . htmlentities($_POST['email'], ENT_COMPAT, 'UTF-8') . '"';
	  } ?>
      />
    </p>
  </fieldset>
  <fieldset>
    <legend>Your views</legend>
    <p>
      <label for="comments">Comments: <?php
      if (isset($missing) && in_array('comments', $missing)) { ?>
      <span class="warning">Please enter your comments</span><?php } ?>
      </label>
      <textarea name="comments" id="comments" cols="45" rows="5"><?php 
	  if (isset($missing)) {
		echo htmlentities($_POST['comments'], ENT_COMPAT, 'UTF-8');
	  } ?></textarea>
    </p>
    <p><strong>What aspects of London most interest you?</strong> <?php
      if (isset($missing) && in_array('interests', $missing)) { ?>
      <span class="warning">Please choose at least <?php echo "$minCheckboxes</span>";} ?></p>
    <p class="chkRad">
      <label>
        <input type="checkbox" name="interests[]" value="Classical concerts" id="interests_0"
        <?php
        if (isset($missing) && in_array('Classical concerts', $_POST['interests'])) {
          echo 'checked="checked"';
        } ?>
        />
        Classical concerts</label>
      <br />
      <label>
        <input type="checkbox" name="interests[]" value="Rock/pop" id="interests_1" 
        <?php
        if (isset($missing) && in_array('Rock/pop', $_POST['interests'])) {
          echo 'checked="checked"';
        } ?>
        />
        Rock & pop events</label>
      <br />
      <label>
        <input type="checkbox" name="interests[]" value="Drama" id="interests_2" 
        <?php
        if (isset($missing) && in_array('Drama', $_POST['interests'])) {
          echo 'checked="checked"';
        } ?>
        />
        Drama</label>
      </p>
    <p class="chkRad">
      <label>
        <input type="checkbox" name="interests[]" value="Walks" id="interests_3" 
        <?php
        if (isset($missing) && in_array('Walks', $_POST['interests'])) {
          echo 'checked="checked"';
        } ?>
        />
      Guided walks</label>
      <br />
      <label>
        <input type="checkbox" name="interests[]" value="Art" id="interests_4" 
        <?php
        if (isset($missing) && in_array('Art', $_POST['interests'])) {
          echo 'checked="checked"';
        } ?>
        />
      Art</label>
    </p>
    <p class="clearIt"><strong>Would you like to receive regular details of events in London?</strong></p>
    <p class="chkRad">
      <label>
        <input type="radio" name="subscribe" id="subscribeYes" value="y" 
        <?php
        if (isset($missing) && $_POST['subscribe'] == 'y') {
          echo 'checked="checked"';
        } ?>
        />
        Yes</label>
      </p>
    <p class="chkRad">
      <label>
        <input name="subscribe" type="radio" id="subscribeNo" value="n" 
        <?php
        if (!$_POST || isset($missing) && $_POST['subscribe'] == 'n') {
          echo 'checked="checked"';
        } ?>  
        />
      No</label>
      </p>
    <p class="clearIt">
      <label for="visited">How often have you been to London? <?php
      if (isset($missing) && in_array('visited', $missing)) { ?>
        <span class="warning">Please select a value</span><?php } ?>
      </label>
      <select name="visited" id="visited">
        <option value="0" 
		<?php
        if (!$_POST || $_POST['visited'] == '0') {
          echo 'selected="selected"';
        } ?>
        > -- Select one --</option>
        <option value="Never"
        <?php
        if (isset($missing) && $_POST['visited'] == 'Never') {
          echo 'selected="selected"';
        } ?>
        >Never been</option>
        <option value="1-2 times"
        <?php
        if (isset($missing) && $_POST['visited'] == '1-2 times') {
          echo 'selected="selected"';
        } ?>
        >Once or twice</option>
        <option value="Not yearly"
        <?php
        if (isset($missing) && $_POST['visited'] == 'Not yearly') {
          echo 'selected="selected"';
        } ?>
        >Less than once a year</option>
        <option value="Yearly"
        <?php
        if (isset($missing) && $_POST['visited'] == 'Yearly') {
          echo 'selected="selected"';
        } ?>
        >I go most years</option>
        <option value="Resident"
        <?php
        if (isset($missing) && $_POST['visited'] == 'Resident') {
          echo 'selected="selected"';
        } ?>
        >I live there</option>
      </select>
      </p>
    <p>
      <label for="views">What image do you have of London? <?php
      if (isset($missing) && in_array('views', $missing)) { ?>
        <span class="warning">Please select a value</span><?php } ?>
      </label>
      <select name="views[]" size="6" multiple="multiple" id="views">
        <option value="Vibrant/exciting"
        <?php
        if (isset($missing) && in_array('Vibrant/exciting', $_POST['views'])) {
          echo 'selected="selected"';
        } ?>
        >A vibrant, exciting city</option>
        <option value="Good food"
        <?php
        if (isset($missing) && in_array('Good food', $_POST['views'])) {
          echo 'selected="selected"';
        } ?>
        >A great place to eat</option>
        <option value="Good transport"
        <?php
        if (isset($missing) && in_array('Good transport', $_POST['views'])) {
          echo 'selected="selected"';
        } ?>
        >Convenient transport</option>
        <option value="Dull"
        <?php
        if (isset($missing) && in_array('Dull', $_POST['views'])) {
          echo 'selected="selected"';
        } ?>
        >Dull, dull, dull</option>
        <option value="Bad food"
        <?php
        if (isset($missing) && in_array('Bad food', $_POST['views'])) {
          echo 'selected="selected"';
        } ?>
        >The food's rotten</option>
        <option value="Transport nightmare"
        <?php
        if (isset($missing) && in_array('Transport nightmare', $_POST['views'])) {
          echo 'selected="selected"';
        } ?>
        >A transport nightmare</option>
      </select>
      </p>
    <p class="clearIt">
      <input name="send" type="submit" id="send" value="Send comments" />
    </p>
  </fieldset>
</form>
</body>
</html>