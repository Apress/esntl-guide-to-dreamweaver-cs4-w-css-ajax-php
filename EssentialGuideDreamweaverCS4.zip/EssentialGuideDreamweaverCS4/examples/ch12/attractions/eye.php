<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Stroll Along the Thames: London Eye</title>
<link href="../stroll.css" rel="stylesheet" type="text/css" />
<link href="../../../SpryAssets/SpryMenuBarHorizontal_stroll.css" rel="stylesheet" type="text/css" />
<!--[if IE 5]>
<style type="text/css"> 
/* place css box model fixes for IE 5* in this conditional comment */
.twoColFixLtHdr #sidebar1 { width: 230px; }
</style>
<![endif]--><!--[if IE]>
<style type="text/css"> 
/* place css fixes for all versions of IE in this conditional comment */
.twoColFixLtHdr #sidebar1 { padding-top: 30px; }
.twoColFixLtHdr #mainContent { zoom: 1; }
/* the above proprietary zoom property gives IE the hasLayout it needs to avoid several bugs */
</style>
<![endif]-->
<script type="text/javascript" src="../../../SpryAssets/SpryMenuBar.js"></script>
</head>

<body class="twoColFixLtHdr">

<div id="container">
  <div id="header">
    <h1>Stroll Along the Thames</h1>
    <img src="../../../images/stroll_header.jpg" width="650" height="149" alt="Stroll Along the Thames" />
    <!-- end #header -->
  </div>
  <?php include('../../../workfiles/includes/menu.inc.php'); ?>
  <div id="sidebar1">
    <h3>Flying the London Eye</h3>
    <p>The London Eye is open all year from 10am until 8pm daily. During the summer, it stays open until 9pm in June and September, and until 9.30pm in July and August.</p>
    <blockquote>
      <p>The London Eye carries 3.5 million customers every year. You would need 6,680 fully booked British Airways Boeing 747-400 jumbo jets to move that number of fliers!</p>
      <p id="quote_attrib">London Eye Visitor Information</p>
    </blockquote>
    <p>Donec eu mi sed turpis feugiat feugiat. Integer turpis arcu, pellentesque  eget, cursus et, fermentum ut, sapien. Fusce metus mi, eleifend  sollicitudin, molestie id, varius et, nibh. Donec nec libero.</p>
  <!-- end #sidebar1 --></div>
  <div id="mainContent">
    <h2> Eye Dominates London Skyline</h2>
    <p>At the opposite end of St James's Park to Buckingham Palace lies Whitehall&#8212;home to many government buildings, including the Foreign Office, the Treasury, and the Prime Minister's official residence at 10 Downing Street. <img src="../../../images/eye_stjames.jpg" alt="London Eye seen from St James's Park" width="365" height="249" class="fltlft" />A newcomer keeping a watch over them all is the London Eye, the futuristic, yet elegant observation wheel.</p>
    <p>The Eye stands 135 metres (443 feet) tall, and when it opened on 31 December 1999 was the world's tallest observation wheel. It was originally given planning permission for only five years, but has since been made permanent.</p>
    <p>Etiam leo pede, rhoncus venenatis, tristique in, vulputate at,  odio. Donec et ipsum et sapien vehicula nonummy. Suspendisse potenti. Fusce  varius urna id quam. Sed neque mi, varius eget, tincidunt nec, suscipit id,  libero. In eget purus. Vestibulum ut nisl.</p>
<p><img src="../../../images/eye.jpg" alt="Graffiti artists at work" width="247" height="333" class="fltrt" />Donec eu mi sed turpis feugiat feugiat. Integer turpis arcu, pellentesque eget, cursus et, fermentum ut,  sapien. Fusce metus mi, eleifend sollicitudin, molestie id, varius et, nibh.  Donec nec libero. </p>
    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent aliquam,  justo convallis luctus rutrum, erat nulla fermentum diam, at nonummy quam  ante ac quam. Maecenas urna purus, fermentum id, molestie in, commodo  porttitor, felis. Nam blandit quam ut lacus. Quisque ornare risus quis  ligula. Phasellus tristique purus a augue condimentum adipiscing. Aenean  sagittis. Etiam leo pede, rhoncus venenatis, tristique in, vulputate at, odio.</p>
	<!-- end #mainContent --></div>
	<!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats --><br class="clearfloat" />
  <div id="footer">
    <p>&copy; Footsore in London</p>
  <!-- end #footer --></div>
<!-- end #container --></div>
</body>
</html>
