<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connQuery, $connQuery);
$query_getPhotos = "SELECT filename, category, width, height, caption, `description` FROM ch19_gallery";
$getPhotos = mysql_query($query_getPhotos, $connQuery) or die(mysql_error());
$row_getPhotos = mysql_fetch_assoc($getPhotos);
$totalRows_getPhotos = mysql_num_rows($getPhotos);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:spry="http://ns.adobe.com/spry">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Photo Gallery: England &amp; Japan</title>
<link href="spry_table.css" rel="stylesheet" type="text/css" />
<script src="../../SpryAssets/SpryData.js" type="text/javascript"></script>
<script src="../../SpryAssets/SpryHTMLDataSet.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
var dsPhotos = new Spry.Data.HTMLDataSet(null, "photos");
dsPhotos.setColumnType("Description", "html");
//-->
</script>
</head>

<body>
<div id="spryTable" spry:region="dsPhotos">
  <table>
    <tr>
      <th spry:sort="Thumbnail">Thumbnail</th>
      <th spry:sort="Caption">Caption</th>
    </tr>
    <tr spry:repeat="dsPhotos" spry:setrow="dsPhotos" spry:odd="odd" spry:even="even" spry:hover="hover" spry:select="selected">
      <td>{Thumbnail}</td>
      <td>{Caption}</td>
    </tr>
  </table>
</div>
<div id="details" spry:detailregion="dsPhotos">
  <p>{Image}</p>
{Description} </div>
<table width="100%" id="photos">
  <tr>
    <th scope="col">Thumbnail</th>
    <th scope="col">Image</th>
    <th scope="col">Caption</th>
    <th scope="col">Description</th>
    <th scope="col">Category</th>
  </tr>
  <?php do { ?>
    <tr>
      <td><img src="../../images/gallery/thumbs/<?php echo $row_getPhotos['filename']; ?>" alt="" width="80" height="54" /></td>
      <td><img src="../../images/gallery/<?php echo $row_getPhotos['filename']; ?>" alt="<?php echo $row_getPhotos['caption']; ?>" width="<?php echo $row_getPhotos['width']; ?>" height="<?php echo $row_getPhotos['height']; ?>" /></td>
      <td><?php echo $row_getPhotos['caption']; ?></td>
      <td><?php echo $row_getPhotos['description']; ?></td>
      <td><?php echo $row_getPhotos['category']; ?></td>
    </tr>
    <?php } while ($row_getPhotos = mysql_fetch_assoc($getPhotos)); ?>
</table>
<table width="150" id="galleries">
  <tr>
    <td>ENG</td>
    <td>England</td>
  </tr>
  <tr>
    <td>JPN</td>
    <td>Japan</td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($getPhotos);
?>
