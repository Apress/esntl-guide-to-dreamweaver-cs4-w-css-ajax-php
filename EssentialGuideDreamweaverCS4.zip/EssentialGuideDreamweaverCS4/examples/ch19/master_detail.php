<?php require_once('../../Connections/connQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_connQuery, $connQuery);
$query_getJPNphotos = "SELECT filename, width, height, caption, `description` FROM ch19_gallery WHERE category = 'JPN'";
$getJPNphotos = mysql_query($query_getJPNphotos, $connQuery) or die(mysql_error());
$row_getJPNphotos = mysql_fetch_assoc($getJPNphotos);
$totalRows_getJPNphotos = mysql_num_rows($getJPNphotos);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:spry="http://ns.adobe.com/spry">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Photo gallery: Japan</title>
<script src="../../SpryAssets/SpryData.js" type="text/javascript"></script>
<script src="../../SpryAssets/SpryHTMLDataSet.js" type="text/javascript"></script>
<link href="../../SpryAssets/SpryMasterDetail.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
var dsPhotos = new Spry.Data.HTMLDataSet(null, "JPNdata");
dsPhotos.setColumnType("Description", "html");
//-->
</script>
</head>

<body>
<div class="MasterDetail">
  <div spry:region="dsPhotos" class="MasterContainer">
    <div class="MasterColumn" spry:repeat="dsPhotos" spry:setrow="dsPhotos" spry:hover="MasterColumnHover" spry:select="MasterColumnSelected">{Caption}</div>
  </div>
  <div spry:detailregion="dsPhotos" class="DetailContainer">
    <p class="DetailColumn">{Image}</p>
    <div class="DetailColumn">{Description}</div>
  </div>
  <br style="clear:both" />
</div>
<table width="100%" id="JPNdata">
  <tr>
    <th scope="col">Thumbnail</th>
    <th scope="col">Image</th>
    <th scope="col">Caption</th>
    <th scope="col">Description</th>
  </tr>
  <?php do { ?>
    <tr>
      <td><img src="../../images/gallery/thumbs/<?php echo $row_getJPNphotos['filename']; ?>" alt="" width="80" height="54" /></td>
      <td><img src="../../images/gallery/<?php echo $row_getJPNphotos['filename']; ?>" alt="<?php echo $row_getJPNphotos['caption']; ?>" width="<?php echo $row_getJPNphotos['width']; ?>" height="<?php echo $row_getJPNphotos['height']; ?>" /></td>
      <td><?php echo $row_getJPNphotos['caption']; ?></td>
      <td><?php echo $row_getJPNphotos['description']; ?></td>
    </tr>
    <?php } while ($row_getJPNphotos = mysql_fetch_assoc($getJPNphotos)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($getJPNphotos);
?>
