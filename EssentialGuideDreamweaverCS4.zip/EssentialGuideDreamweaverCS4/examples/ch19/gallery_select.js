
var dsPhotos = new Spry.Data.HTMLDataSet(null, "photos");
dsPhotos.setColumnType("Description", "html");
dsPhotos.gallery = 'ENG';
function chooseSet(dataSet, row, rowNumber)
{
	if (row['Category'] == dsPhotos.gallery) {
		return row;
	} 
	return null;
}
dsPhotos.filter(chooseSet);
function changeSet(set)
{
	dsPhotos.gallery = set;
	dsPhotos.filter(chooseSet);
	dsPhotos.setCurrentRowNumber(0);
	var rows = dsPhotos.getData();
	for (var i = 0; i < rows.length; i++) {
		if (rows[i]['Category'] == set) {
			dsPhotos.setCurrentRowNumber(i);
			break;
		}
	}
}
var dsGalleries = new Spry.Data.HTMLDataSet(null, "galleries", {firstRowAsHeaders: false, columnNames: ['source', 'label']});



Spry.Utils.addLoadListener(function() {
	Spry.$$("#div1").setAttribute('spry:region', 'dsGalleries');
	Spry.$$("#selectGallery").setAttribute('spry:repeatchildren', 'dsGalleries');
	Spry.$$("#selectGallery").setAttribute('spry:choose', 'spry:choose');
	Spry.$$("#selectGallery").setAttribute('onchange', 'changeSet(this.value)');
	Spry.$$("#option1").setAttribute('spry:when', '{ds_CurrentRowID} == {ds_RowID}');
	Spry.$$("#option1").forEach(function(n){ n.id = n.id + "_1_{dsGalleries::ds_RowID}"; }); // Ensures each instance of this repeating element has a unique id.
	Spry.$$("#option2").setAttribute('spry:default', 'spry:default');
	Spry.$$("#option2").forEach(function(n){ n.id = n.id + "_1_{dsGalleries::ds_RowID}"; }); // Ensures each instance of this repeating element has a unique id.
	Spry.$$("#spryTable").setAttribute('spry:region', 'dsPhotos');
	Spry.$$("#th1").setAttribute('spry:sort', 'Thumbnail');
	Spry.$$("#th2").setAttribute('spry:sort', 'Caption');
	Spry.$$("#tr1").setAttribute('spry:repeat', 'dsPhotos');
	Spry.$$("#tr1").setAttribute('spry:setrow', 'dsPhotos');
	Spry.$$("#tr1").setAttribute('spry:odd', 'odd');
	Spry.$$("#tr1").setAttribute('spry:even', 'even');
	Spry.$$("#tr1").setAttribute('spry:hover', 'hover');
	Spry.$$("#tr1").setAttribute('spry:select', 'selected');
	Spry.$$("#tr1").forEach(function(n){ n.id = n.id + "_2_{dsPhotos::ds_RowID}"; }); // Ensures each instance of this repeating element has a unique id.
	Spry.$$("#details").setAttribute('spry:detailregion', 'dsPhotos');

	Spry.Data.initRegions();
});
