<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:spry="http://ns.adobe.com/spry">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Spry data set from XML</title>
<script src="../../SpryAssets/xpath.js" type="text/javascript"></script>
<script src="../../SpryAssets/SpryData.js" type="text/javascript"></script>
<link href="../../SpryAssets/SpryMasterDetail.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
var dsPhotos = new Spry.Data.XMLDataSet("../../examples/ch19/england.xml", "gallery/photo");
dsPhotos.setColumnType("file/@height", "number");
dsPhotos.setColumnType("file/@width", "number");
dsPhotos.setColumnType("description", "html");
//-->
</script>
</head>

<body>
<div class="MasterDetail">
  <div spry:region="dsPhotos" class="MasterContainer">
    <div class="MasterColumn" spry:repeat="dsPhotos" spry:setrow="dsPhotos" spry:hover="MasterColumnHover" spry:select="MasterColumnSelected">{caption}</div>
  </div>
  <div spry:detailregion="dsPhotos" class="DetailContainer">
    <p class="DetailColumn"><img src="../../images/gallery/{file}" alt="{caption}" width="{file/@width}" height="{file/@height}" /></p>
    <div class="DetailColumn">{description}</div>
  </div>
  <br style="clear:both" />
</div>
</body>
</html>